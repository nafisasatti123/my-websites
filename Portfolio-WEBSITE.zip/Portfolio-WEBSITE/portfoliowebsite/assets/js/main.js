document.addEventListener('DOMContentLoaded', function () {
    // Initialize AOS
    AOS.init({
        // Settings that can be overridden on a per-element basis, by `data-aos-*` attributes:
        offset: 120,
        delay: 0,
        duration: 400,
        easing: 'ease',
        once: false,
        mirror: false,
        anchorPlacement: 'top-bottom'
    });

    console.log('JavaScript is working!');
    // Add more JavaScript code as needed
});
